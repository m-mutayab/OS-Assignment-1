// Q1. FCFS (First Come First Serve) Scheduling
// Input arrival time and burst time of n processes.
// Calculate Completion Time, Turnaround Time, Waiting Time, and Average Waiting Time.

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Process {
    int id;
    int arrival;
    int burst;
    int completion;
    int turnaround;
    int waiting;
};

int main() {
    int n;
    cout << "Enter number of processes: ";
    cin >> n;

    vector<Process> p(n);

    for (int i = 0; i < n; i++) {
        p[i].id = i + 1;
        cout << "Enter arrival time and burst time for process P" << p[i].id << ": ";
        cin >> p[i].arrival >> p[i].burst;
    }

    // FCFS -> sort by arrival time (process that arrives first is served first)
    sort(p.begin(), p.end(), [](const Process &a, const Process &b) {
        return a.arrival < b.arrival;
    });

    int currentTime = 0;
    float totalWaiting = 0, totalTurnaround = 0;

    for (int i = 0; i < n; i++) {
        if (currentTime < p[i].arrival)
            currentTime = p[i].arrival;

        currentTime += p[i].burst;
        p[i].completion = currentTime;
        p[i].turnaround = p[i].completion - p[i].arrival;
        p[i].waiting = p[i].turnaround - p[i].burst;

        totalWaiting += p[i].waiting;
        totalTurnaround += p[i].turnaround;
    }

    cout << "\nPID\tArrival\tBurst\tCompletion\tTurnaround\tWaiting\n";
    for (int i = 0; i < n; i++) {
        cout << "P" << p[i].id << "\t" << p[i].arrival << "\t" << p[i].burst
             << "\t" << p[i].completion << "\t\t" << p[i].turnaround
             << "\t\t" << p[i].waiting << "\n";
    }

    cout << "\nAverage Waiting Time = " << (totalWaiting / n);
    cout << "\nAverage Turnaround Time = " << (totalTurnaround / n) << "\n";

    return 0;
}
