// Q2. Non-Preemptive SJF (Shortest Job First) Scheduling
// Take process ID and burst time as input.
// Display execution order and average waiting time.
// (Arrival time assumed 0 for all processes since only PID and burst time are given)

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Process {
    int id;
    int burst;
    int completion;
    int turnaround;
    int waiting;
};

int main() {
    int n;
    cout << "Enter number of processes: ";
    cin >> n;

    vector<Process> p(n);

    for (int i = 0; i < n; i++) {
        cout << "Enter Process ID for process " << i + 1 << ": ";
        cin >> p[i].id;
        cout << "Enter Burst Time for process " << p[i].id << ": ";
        cin >> p[i].burst;
    }

    // Non-preemptive SJF -> sort by burst time (shortest job runs first)
    sort(p.begin(), p.end(), [](const Process &a, const Process &b) {
        return a.burst < b.burst;
    });

    int currentTime = 0;
    float totalWaiting = 0, totalTurnaround = 0;

    cout << "\nExecution Order: ";
    for (int i = 0; i < n; i++) {
        cout << "P" << p[i].id;
        if (i != n - 1) cout << " -> ";

        currentTime += p[i].burst;
        p[i].completion = currentTime;
        p[i].turnaround = p[i].completion; // arrival = 0
        p[i].waiting = p[i].turnaround - p[i].burst;

        totalWaiting += p[i].waiting;
        totalTurnaround += p[i].turnaround;
    }
    cout << "\n";

    cout << "\nPID\tBurst\tCompletion\tTurnaround\tWaiting\n";
    for (int i = 0; i < n; i++) {
        cout << "P" << p[i].id << "\t" << p[i].burst << "\t" << p[i].completion
             << "\t\t" << p[i].turnaround << "\t\t" << p[i].waiting << "\n";
    }

    cout << "\nAverage Waiting Time = " << (totalWaiting / n);
    cout << "\nAverage Turnaround Time = " << (totalTurnaround / n) << "\n";

    return 0;
}
