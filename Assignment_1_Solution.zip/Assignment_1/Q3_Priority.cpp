// Q3. Priority Scheduling (Non-Preemptive)
// Each process has Process ID, Burst Time, and Priority (lower number = higher priority).
// Calculate waiting time and turnaround time.

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Process {
    int id;
    int burst;
    int priority;
    int completion;
    int turnaround;
    int waiting;
};

int main() {
    int n;
    cout << "Enter number of processes: ";
    cin >> n;

    vector<Process> p(n);

    for (int i = 0; i < n; i++) {
        cout << "Enter Process ID for process " << i + 1 << ": ";
        cin >> p[i].id;
        cout << "Enter Burst Time for process " << p[i].id << ": ";
        cin >> p[i].burst;
        cout << "Enter Priority for process " << p[i].id << " (lower = higher priority): ";
        cin >> p[i].priority;
    }

    // Sort by priority (lower number executes first)
    sort(p.begin(), p.end(), [](const Process &a, const Process &b) {
        return a.priority < b.priority;
    });

    int currentTime = 0;
    float totalWaiting = 0, totalTurnaround = 0;

    for (int i = 0; i < n; i++) {
        currentTime += p[i].burst;
        p[i].completion = currentTime;
        p[i].turnaround = p[i].completion; // arrival = 0
        p[i].waiting = p[i].turnaround - p[i].burst;

        totalWaiting += p[i].waiting;
        totalTurnaround += p[i].turnaround;
    }

    cout << "\nPID\tPriority\tBurst\tCompletion\tTurnaround\tWaiting\n";
    for (int i = 0; i < n; i++) {
        cout << "P" << p[i].id << "\t" << p[i].priority << "\t\t" << p[i].burst
             << "\t" << p[i].completion << "\t\t" << p[i].turnaround
             << "\t\t" << p[i].waiting << "\n";
    }

    cout << "\nAverage Waiting Time = " << (totalWaiting / n);
    cout << "\nAverage Turnaround Time = " << (totalTurnaround / n) << "\n";

    return 0;
}
