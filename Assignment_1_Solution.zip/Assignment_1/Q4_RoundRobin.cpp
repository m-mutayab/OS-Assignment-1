// Q4. Round Robin Scheduling
// Input number of processes, burst time of each process, and time quantum.
// Calculate waiting time and turnaround time.

#include <iostream>
#include <vector>
#include <queue>
using namespace std;

struct Process {
    int id;
    int burst;
    int remaining;
    int completion;
    int turnaround;
    int waiting;
};

int main() {
    int n, quantum;
    cout << "Enter number of processes: ";
    cin >> n;

    vector<Process> p(n);

    for (int i = 0; i < n; i++) {
        p[i].id = i + 1;
        cout << "Enter Burst Time for process P" << p[i].id << ": ";
        cin >> p[i].burst;
        p[i].remaining = p[i].burst;
    }

    cout << "Enter Time Quantum: ";
    cin >> quantum;

    queue<int> q; // stores index of process
    for (int i = 0; i < n; i++) q.push(i);

    int currentTime = 0;

    while (!q.empty()) {
        int i = q.front();
        q.pop();

        if (p[i].remaining > quantum) {
            currentTime += quantum;
            p[i].remaining -= quantum;
            q.push(i); // process not finished, push back to queue
        } else {
            currentTime += p[i].remaining;
            p[i].remaining = 0;
            p[i].completion = currentTime;
            p[i].turnaround = p[i].completion; // arrival = 0
            p[i].waiting = p[i].turnaround - p[i].burst;
        }
    }

    float totalWaiting = 0, totalTurnaround = 0;
    for (int i = 0; i < n; i++) {
        totalWaiting += p[i].waiting;
        totalTurnaround += p[i].turnaround;
    }

    cout << "\nPID\tBurst\tCompletion\tTurnaround\tWaiting\n";
    for (int i = 0; i < n; i++) {
        cout << "P" << p[i].id << "\t" << p[i].burst << "\t" << p[i].completion
             << "\t\t" << p[i].turnaround << "\t\t" << p[i].waiting << "\n";
    }

    cout << "\nAverage Waiting Time = " << (totalWaiting / n);
    cout << "\nAverage Turnaround Time = " << (totalTurnaround / n) << "\n";

    return 0;
}
