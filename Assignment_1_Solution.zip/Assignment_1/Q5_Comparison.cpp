// Q5. Comparison of Scheduling Algorithms
// Run the same set of processes using FCFS, SJF, and Priority Scheduling.
// Compare average waiting time and identify the best-performing algorithm.
// (All processes are assumed to arrive at time 0, so the algorithms can be
//  fairly compared using Process ID, Burst Time, and Priority.)

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Process {
    int id;
    int burst;
    int priority;
};

// Generic function: given an order of processes (already sorted for the
// algorithm being tested), computes and returns the average waiting time.
float calculateAvgWaitingTime(vector<Process> p) {
    int currentTime = 0;
    float totalWaiting = 0;

    for (size_t i = 0; i < p.size(); i++) {
        currentTime += p[i].burst;
        int turnaround = currentTime;              // arrival = 0
        int waiting = turnaround - p[i].burst;
        totalWaiting += waiting;
    }
    return totalWaiting / p.size();
}

int main() {
    int n;
    cout << "Enter number of processes: ";
    cin >> n;

    vector<Process> original(n);

    for (int i = 0; i < n; i++) {
        original[i].id = i + 1;
        cout << "Enter Burst Time for process P" << original[i].id << ": ";
        cin >> original[i].burst;
        cout << "Enter Priority for process P" << original[i].id << " (lower = higher priority): ";
        cin >> original[i].priority;
    }

    // ---- FCFS: same order processes were entered (arrival order) ----
    vector<Process> fcfs = original;
    float avgFCFS = calculateAvgWaitingTime(fcfs);

    // ---- SJF: sort by burst time ----
    vector<Process> sjf = original;
    sort(sjf.begin(), sjf.end(), [](const Process &a, const Process &b) {
        return a.burst < b.burst;
    });
    float avgSJF = calculateAvgWaitingTime(sjf);

    // ---- Priority: sort by priority ----
    vector<Process> priority = original;
    sort(priority.begin(), priority.end(), [](const Process &a, const Process &b) {
        return a.priority < b.priority;
    });
    float avgPriority = calculateAvgWaitingTime(priority);

    cout << "\n--- Comparison of Average Waiting Time ---\n";
    cout << "FCFS Average Waiting Time      : " << avgFCFS << "\n";
    cout << "SJF Average Waiting Time       : " << avgSJF << "\n";
    cout << "Priority Average Waiting Time  : " << avgPriority << "\n";

    // Identify the best performing algorithm (lowest average waiting time)
    string best = "FCFS";
    float bestValue = avgFCFS;

    if (avgSJF < bestValue) {
        best = "SJF";
        bestValue = avgSJF;
    }
    if (avgPriority < bestValue) {
        best = "Priority";
        bestValue = avgPriority;
    }

    cout << "\nBest Performing Algorithm: " << best
         << " (Average Waiting Time = " << bestValue << ")\n";

    return 0;
}
