# Assignment 1 — CPU Scheduling Algorithms

Language: C++

## Files
| File | Description |
|------|--------------|
| `Q1_FCFS.cpp` | First Come First Serve scheduling — computes Completion, Turnaround, Waiting time, and Average Waiting Time. |
| `Q2_SJF.cpp` | Non-Preemptive Shortest Job First scheduling — shows execution order and average waiting time. |
| `Q3_Priority.cpp` | Non-Preemptive Priority scheduling (lower number = higher priority) — computes waiting and turnaround time. |
| `Q4_RoundRobin.cpp` | Round Robin scheduling using a fixed time quantum — computes waiting and turnaround time. |
| `Q5_Comparison.cpp` | Runs the same set of processes through FCFS, SJF, and Priority scheduling and reports which one gives the lowest average waiting time. |

## How to Compile & Run
Each file is independent. Example (Q1):

```bash
g++ -std=c++17 -o Q1_FCFS Q1_FCFS.cpp
./Q1_FCFS
```

Repeat the same pattern for `Q2_SJF.cpp`, `Q3_Priority.cpp`, `Q4_RoundRobin.cpp`, and `Q5_Comparison.cpp`.

## Notes
- For Q2, Q3, and Q5 (which only specify Process ID / Burst Time / Priority as input), arrival time is assumed to be 0 for all processes, as per the assignment wording.
- Q1 and Q4 explicitly require arrival time / time quantum, so those are taken as input.
- All programs were compiled and tested with sample inputs; no warnings or errors.

## Submission
Push this folder to a GitHub repository before the due date (5th July), and be prepared to present and explain the code in class.
